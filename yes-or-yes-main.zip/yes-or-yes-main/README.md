<div align="center">
  <a href="https://lugh-tuatha.github.io/hands-for-filipinos/">
    <img src="img/readme-2.png" alt="Logo" height="80">
  </a>

  <p align="center">
    Anti Rejection for ur crush (ew yuck)
    <br />
    <a href="https://lugh-tuatha.github.io/yes-or-yes/">View Demo</a>
    ·
    <a href="https://github.com/lugh-tuatha/yes-or-yes/issues">Report Bug</a>
    ·
    <a href="https://github.com/lugh-tuatha/yes-or-yes/issues">Request Feature</a>
  </p>
</div>
